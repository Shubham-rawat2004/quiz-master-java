package com.Anudip.Smart.Skill.Workload.Management.System.Repository;

import com.Anudip.Smart.Skill.Workload.Management.System.Entity.TaskAssignment;
import com.Anudip.Smart.Skill.Workload.Management.System.Entity.TaskStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TaskAssignmentRepository extends JpaRepository<TaskAssignment, Long> {
    List<TaskAssignment> findByUser_Id(Long userId);

    List<TaskAssignment> findByTask_Id(Long taskId);

    List<TaskAssignment> findByUser_IdAndTask_TaskStatusIn(Long userId, List<TaskStatus> statuses);

    List<TaskAssignment> findByUser_IdAndTask_TaskStatusNot(Long userId, TaskStatus status);
}
