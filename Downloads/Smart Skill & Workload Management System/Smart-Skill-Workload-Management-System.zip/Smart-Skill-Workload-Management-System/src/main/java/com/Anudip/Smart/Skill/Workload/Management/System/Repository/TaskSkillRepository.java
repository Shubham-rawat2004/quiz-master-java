package com.Anudip.Smart.Skill.Workload.Management.System.Repository;

import com.Anudip.Smart.Skill.Workload.Management.System.Entity.TaskSkill;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TaskSkillRepository extends JpaRepository<TaskSkill, Long> {
    List<TaskSkill> findByTask_Id(Long taskId);
}
