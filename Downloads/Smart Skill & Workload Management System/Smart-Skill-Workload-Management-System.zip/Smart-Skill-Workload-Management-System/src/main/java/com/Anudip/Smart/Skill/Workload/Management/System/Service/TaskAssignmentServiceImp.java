package com.Anudip.Smart.Skill.Workload.Management.System.Service;


import com.Anudip.Smart.Skill.Workload.Management.System.Entity.*;
import com.Anudip.Smart.Skill.Workload.Management.System.Repository.TaskAssignmentRepository;
import com.Anudip.Smart.Skill.Workload.Management.System.Repository.TaskRepository;
import com.Anudip.Smart.Skill.Workload.Management.System.Repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class TaskAssignmentServiceImp implements TaskAssignmentService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    private final TaskAssignmentRepository taskAssignmentRepository;

    public TaskAssignmentServiceImp(
            TaskRepository taskRepository,
            UserRepository userRepository,
            TaskAssignmentRepository taskAssignmentRepository
    ) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
        this.taskAssignmentRepository = taskAssignmentRepository;
    }

    @Override
    public void assignTask(Long taskId) {

        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        if (task.getTaskStatus() != TaskStatus.PENDING) {
            throw new IllegalStateException("Task is already assigned or completed");
        }

        List<User> users = userRepository.findAll();

        User bestUser = null;
        double bestScore = Double.NEGATIVE_INFINITY;

        for (User user : users) {

            if (!isUserEligible(user, task)) {
                continue;
            }

            double score = calculateScore(user, task);

            if (score > bestScore) {
                bestScore = score;
                bestUser = user;
            }
        }

        if (bestUser == null) {
            throw new RuntimeException("No suitable user found for task");
        }

        TaskAssignment assignment = new TaskAssignment();
        assignment.setTask(task);
        assignment.setUser(bestUser);
        assignment.setAssignedDate(LocalDate.now());

        task.setTaskStatus(TaskStatus.ASSIGNED);
//        bestUser.setAvailabilityHours(
//                bestUser.getAvailabilityHours() - task.getRequiredEffortHours()
//        );

        taskAssignmentRepository.save(assignment);
    }

    private int getUserWorkload(User user) {
        List<TaskAssignment> assignments =
                taskAssignmentRepository.findByUser_IdAndTask_TaskStatusNot(
                        user.getId(),
                        TaskStatus.COMPLETED
                );

        return assignments.stream()
                .map(TaskAssignment::getTask)
                .mapToInt(Task::getRequiredEffortHours)
                .sum();
    }
    // ---------- HELPER METHODS ----------

    private boolean isUserEligible(User user, Task task) {

        int workload = getUserWorkload(user);

        if ((workload + task.getRequiredEffortHours()) > user.getAvailabilityHours()) {
            return false;
        }

        for (TaskSkill required : task.getRequiredSkills()) {

            boolean hasSkill = user.getSkills().stream()
                    .anyMatch(us ->
                            us.getSkill().getId().equals(required.getSkill().getId())
                                    && us.getProficiencyLevel() >= required.getMinimumProficiency()
                    );

            if (!hasSkill) {
                return false;
            }
        }
        return true;
    }

    private double calculateScore(User user, Task task) {

        int matchedSkills = 0;
        int totalProficiency = 0;

        for (TaskSkill required : task.getRequiredSkills()) {
            for (UserSkill us : user.getSkills()) {
                if (us.getSkill().getId().equals(required.getSkill().getId())) {
                    matchedSkills++;
                    totalProficiency += us.getProficiencyLevel();
                }
            }
        }

        double skillMatchRatio =
                (double) matchedSkills / task.getRequiredSkills().size();

        double avgProficiency =
                matchedSkills == 0 ? 0 : (double) totalProficiency / matchedSkills;

        int workload = getUserWorkload(user);

        return (skillMatchRatio * 0.5)
                + ((avgProficiency / 10) * 0.3)
                - (workload * 0.02); // penalty
    }
}

